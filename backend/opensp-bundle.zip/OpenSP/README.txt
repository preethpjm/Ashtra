OpenSP (onsgmls, osx) for ASTHRA, with the DLLs these programs import.
Exported from a working installation ("OpenSP" version "1.5.2").

Install on the other PC (no internet needed):
    python -m asthra.cli install-opensp <this zip>
    python -m asthra.cli doctor

OpenSP is under a permissive MIT-style licence; the msys-*.dll files are the MSYS2 runtime
and GCC support libraries under their own open-source licences (see LICENSES).
